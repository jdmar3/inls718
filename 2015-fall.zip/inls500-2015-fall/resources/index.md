---
layout: page 
title: Resources
---

Here you will find links to online resources that might help you in navigating the work conducted as part of this course. 

## APA Style

[APA6 Style: Purdue Online Writing Lab](https://owl.english.purdue.edu/owl/resource/560/01/)

## ACM Styles

[ACM Reference Guide](http://www.cs.ucy.ac.cy/~chryssis/specs/ACM-refguide.pdf)

[ACM Word Style Guide](http://www.acm.org/publications/article-templates/word-style-guide)